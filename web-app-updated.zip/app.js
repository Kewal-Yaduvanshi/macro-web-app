
const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const csrf = require('csurf');
const authRoutes = require('./routes/auth');
const otpRoutes = require('./routes/otp');

const app = express();
const PORT = 3000;

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true
}));
app.use(csrf()); // Enable CSRF protection
app.set('view engine', 'ejs');
app.use(express.static('public'));

// Redirect root URL to login
app.get('/', (req, res) => {
  res.redirect('/login');
});

// CSRF Error Handling
app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    return res.status(403).send('CSRF token validation failed.');
  }
  next();
});

// Routes
app.use('/', authRoutes);
app.use('/otp', otpRoutes);

// Server listening
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
