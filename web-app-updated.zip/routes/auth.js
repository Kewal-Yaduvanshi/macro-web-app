
const express = require('express');
const router = express.Router();

router.get('/login', (req, res) => {
  res.render('login', { csrfToken: req.csrfToken() });
});

router.post('/login', (req, res) => {
  // Assume user authentication is always successful
  req.session.authenticated = true;
  req.session.otpAttempts = 0;
  res.redirect('/otp');
});

router.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/login');
});

module.exports = router;
