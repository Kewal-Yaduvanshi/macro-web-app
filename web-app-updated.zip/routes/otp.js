
const express = require('express');
const router = express.Router();

const correctOtp = '123'; // Hardcoded OTP for demo purposes

router.get('/', (req, res) => {
  res.render('otp', { errorMessage: null, csrfToken: req.csrfToken() });
});

router.post('/', (req, res) => {
  const { otp } = req.body;
  if (otp === correctOtp) {
    req.session.otpVerified = true;
    res.redirect('/home');
  } else {
    req.session.otpAttempts += 1;
    if (req.session.otpAttempts >= 2) {
      req.session.destroy();
      res.redirect('/login');
    } else {
      res.render('otp', { errorMessage: 'Incorrect OTP. Please try again.', csrfToken: req.csrfToken() });
    }
  }
});

router.get('/home', (req, res) => {
  if (!req.session.otpVerified) {
    return res.redirect('/login');
  }
  res.render('home', { csrfToken: req.csrfToken() });
});

router.get('/dashboard', (req, res) => {
  if (!req.session.otpVerified) {
    return res.redirect('/login');
  }
  res.render('dashboard', { csrfToken: req.csrfToken() });
});

module.exports = router;
